This version...
I won't lie. It sucks.
It's python, for one thing. You need an interpreter on the target.
For another, it's not encrypted. 
And finally, it doesn't work on Windows. At least, not the versions I've tested.
But it's a start - most importantly, it deals with handshakes. It's an experiment and works GREAT on linux. But Windows development is failing.